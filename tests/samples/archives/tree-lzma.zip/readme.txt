An archive made for the tests.
